# AWS_CICD
This project about CICD using AWS
![img.png](img.png)